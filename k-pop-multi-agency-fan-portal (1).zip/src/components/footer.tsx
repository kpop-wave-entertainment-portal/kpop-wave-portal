import Link from "next/link";
import { Camera, Music2, Play, Sparkles } from "lucide-react";

export function Footer() {
  return <footer className="footer"><div className="footer-inner">
    <div><Link className="brand" href="/"><span className="brand-mark"><Sparkles size={17}/></span><span>K-POP <b>ATLAS</b></span></Link><p>Your trusted bridge to the global K-Pop universe. Verified rosters, personalized fan services, one destination.</p><div className="socials"><a href="#" aria-label="Instagram"><Camera/></a><a href="#" aria-label="YouTube"><Play/></a><a href="#" aria-label="TikTok"><Music2/></a></div></div>
    <div><h4>Explore</h4><Link href="/companies">Companies</Link><Link href="/artists">Artists</Link><Link href="/inquiry">Fan Services</Link><Link href="/dashboard">My Atlas</Link></div>
    <div><h4>Support</h4><Link href="/inquiry">Contact us</Link><Link href="/about">About Atlas</Link><Link href="/legal">Privacy policy</Link><Link href="/legal">Terms of service</Link></div>
    <div><h4>Stay in the loop</h4><p>Curated K-Pop updates, delivered weekly.</p><form action="https://formspree.io/f/xykrybvv" method="POST" className="newsletter"><input type="email" name="email" required placeholder="Your email address"/><button aria-label="Subscribe">→</button></form></div>
  </div><div className="footer-bottom"><span>© 2026 K-POP ATLAS. All rights reserved.</span><span>Seoul · Los Angeles · Tokyo</span></div></footer>
}
