"use client";
import Script from "next/script";

export function TawkWidget() {
  return <Script id="tawk-widget" strategy="afterInteractive">{`
    var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
    (function(){var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];s1.async=true;s1.src='https://embed.tawk.to/6a552c0bf9a2241d47e6e3f3/default';s1.charset='UTF-8';s1.setAttribute('crossorigin','*');s0.parentNode.insertBefore(s1,s0);})();
  `}</Script>;
}
