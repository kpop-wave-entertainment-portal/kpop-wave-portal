"use client";

import Link from "next/link";
import { ChevronDown, Menu, Search, Sparkles, X } from "lucide-react";
import { useEffect, useState } from "react";

const languages = [
  ["en", "EN", "English"], ["ko", "KO", "한국어"], ["ja", "JA", "日本語"],
  ["es", "ES", "Español"], ["pt", "PT", "Português"], ["th", "TH", "ไทย"],
];

export function Header() {
  const [open, setOpen] = useState(false);
  const [lang, setLang] = useState("EN");
  useEffect(() => setLang(localStorage.getItem("atlas-language") || "EN"), []);
  function choose(code: string, label: string) {
    setLang(label); localStorage.setItem("atlas-language", label); document.documentElement.lang = code;
  }
  return (
    <header className="site-header">
      <div className="nav-wrap">
        <Link className="brand" href="/"><span className="brand-mark"><Sparkles size={18}/></span><span>K-POP <b>ATLAS</b></span></Link>
        <nav className={open ? "main-nav open" : "main-nav"} aria-label="Main navigation">
          <Link href="/companies" onClick={() => setOpen(false)}>Companies</Link>
          <Link href="/artists" onClick={() => setOpen(false)}>Artists</Link>
          <Link href="/inquiry" onClick={() => setOpen(false)}>Fan Services</Link>
          <Link href="/dashboard" onClick={() => setOpen(false)}>My Atlas</Link>
          <Link href="/about" onClick={() => setOpen(false)}>About</Link>
        </nav>
        <div className="nav-actions">
          <Link href="/companies" className="icon-btn" aria-label="Search"><Search size={18}/></Link>
          <div className="language-menu">
            <button className="lang-button">{lang}<ChevronDown size={14}/></button>
            <div className="lang-dropdown">{languages.map(([code, short, name]) => <button key={code} onClick={() => choose(code, short)}><span>{short}</span>{name}</button>)}</div>
          </div>
          <Link className="btn btn-small btn-light login-link" href="/login">Sign in</Link>
          <button className="menu-button" onClick={() => setOpen(!open)} aria-label="Toggle menu">{open ? <X/> : <Menu/>}</button>
        </div>
      </div>
    </header>
  );
}
