import { db } from "@/db";
import { artists, companies, users } from "@/db/schema";
import { companySeed, slugify } from "@/db/seed-data";
import { sql } from "drizzle-orm";

export async function ensureDatabase() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS companies (
      id SERIAL PRIMARY KEY, name VARCHAR(160) NOT NULL UNIQUE, slug VARCHAR(180) NOT NULL UNIQUE,
      tier INTEGER NOT NULL, parent_company_id INTEGER, logo TEXT, website_url TEXT, description TEXT
    );
    CREATE TABLE IF NOT EXISTS artists (
      id SERIAL PRIMARY KEY, company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
      name VARCHAR(160) NOT NULL, slug VARCHAR(180) NOT NULL UNIQUE, type VARCHAR(40) NOT NULL DEFAULT 'group',
      debut_year INTEGER, bio TEXT, fandom_name VARCHAR(160), image_url TEXT
    );
    CREATE TABLE IF NOT EXISTS users (
      id SERIAL PRIMARY KEY, email VARCHAR(255) NOT NULL UNIQUE, name VARCHAR(160) NOT NULL,
      role VARCHAR(30) NOT NULL DEFAULT 'fan', avatar_url TEXT, locale VARCHAR(10) NOT NULL DEFAULT 'en',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), last_login_at TIMESTAMPTZ
    );
    CREATE TABLE IF NOT EXISTS inquiries (
      id SERIAL PRIMARY KEY, user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
      artist_id INTEGER REFERENCES artists(id) ON DELETE SET NULL, email VARCHAR(255) NOT NULL,
      inquiry_type VARCHAR(80) NOT NULL, subject VARCHAR(240) NOT NULL, message TEXT NOT NULL,
      status VARCHAR(40) NOT NULL DEFAULT 'new', payment_status VARCHAR(40) NOT NULL DEFAULT 'not_required',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS payments (
      id SERIAL PRIMARY KEY, inquiry_id INTEGER REFERENCES inquiries(id) ON DELETE CASCADE,
      amount NUMERIC(12,2) NOT NULL, provider VARCHAR(40) NOT NULL, status VARCHAR(40) NOT NULL DEFAULT 'pending',
      reference VARCHAR(160), created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS auth_history (
      id SERIAL PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      action VARCHAR(40) NOT NULL, ip_address VARCHAR(80), created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `);

  const existing = await db.select({ id: companies.id }).from(companies).limit(1);
  if (existing.length) return;

  const ids = new Map<string, number>();
  for (const company of companySeed) {
    const [created] = await db.insert(companies).values({
      name: company.name,
      slug: slugify(company.name),
      tier: company.tier,
      description: `${company.name} is a leading Korean entertainment company represented in the K-Pop Atlas global directory.`,
      websiteUrl: "https://www.google.com/search?q=" + encodeURIComponent(company.name),
    }).returning({ id: companies.id });
    ids.set(company.name, created.id);
  }
  for (const company of companySeed.filter((item) => item.parent)) {
    await db.update(companies).set({ parentCompanyId: ids.get(company.parent!) }).where(sql`${companies.id} = ${ids.get(company.name)}`);
  }
  let imageIndex = 0;
  for (const company of companySeed) {
    for (const artist of company.artists) {
      imageIndex += 1;
      await db.insert(artists).values({
        companyId: ids.get(company.name)!, name: artist, slug: slugify(artist),
        type: /BoA|Taeyeon|Kangta|Somi|Taeyang|K\.Will|WOODZ|Sunmi|Bibi|PSY|Crush|Loco|Woo|Kang Daniel|Younha/i.test(artist) ? "soloist" : "group",
        bio: `${artist} is represented by ${company.name}. Follow verified roster details, fan opportunities and official inquiry channels.`,
        imageUrl: `https://images.unsplash.com/photo-${["1501386761578-eac5c94b800a","1493225457124-a3eb161ffa5f","1524650359799-842906ca1c06","1540039155733-5bb30b53aa14","1516280440614-37939bbacd81"][imageIndex % 5]}?auto=format&fit=crop&w=900&q=80`,
      });
    }
  }
  await db.insert(users).values([
    { name: "Mina Park", email: "fan@kpopatlas.com", role: "fan" },
    { name: "Atlas Admin", email: "admin@kpopatlas.com", role: "admin" },
  ]).onConflictDoNothing();
}
