import { integer, numeric, pgTable, serial, text, timestamp, varchar } from "drizzle-orm/pg-core";

export const companies = pgTable("companies", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 160 }).notNull().unique(),
  slug: varchar("slug", { length: 180 }).notNull().unique(),
  tier: integer("tier").notNull(),
  parentCompanyId: integer("parent_company_id"),
  logo: text("logo"),
  websiteUrl: text("website_url"),
  description: text("description"),
});

export const artists = pgTable("artists", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id, { onDelete: "cascade" }),
  name: varchar("name", { length: 160 }).notNull(),
  slug: varchar("slug", { length: 180 }).notNull().unique(),
  type: varchar("type", { length: 40 }).notNull().default("group"),
  debutYear: integer("debut_year"),
  bio: text("bio"),
  fandomName: varchar("fandom_name", { length: 160 }),
  imageUrl: text("image_url"),
});

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 160 }).notNull(),
  role: varchar("role", { length: 30 }).notNull().default("fan"),
  avatarUrl: text("avatar_url"),
  locale: varchar("locale", { length: 10 }).notNull().default("en"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
});

export const inquiries = pgTable("inquiries", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
  artistId: integer("artist_id").references(() => artists.id, { onDelete: "set null" }),
  email: varchar("email", { length: 255 }).notNull(),
  inquiryType: varchar("inquiry_type", { length: 80 }).notNull(),
  subject: varchar("subject", { length: 240 }).notNull(),
  message: text("message").notNull(),
  status: varchar("status", { length: 40 }).notNull().default("new"),
  paymentStatus: varchar("payment_status", { length: 40 }).notNull().default("not_required"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  inquiryId: integer("inquiry_id").references(() => inquiries.id, { onDelete: "cascade" }),
  amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
  provider: varchar("provider", { length: 40 }).notNull(),
  status: varchar("status", { length: 40 }).notNull().default("pending"),
  reference: varchar("reference", { length: 160 }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const authHistory = pgTable("auth_history", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  action: varchar("action", { length: 40 }).notNull(),
  ipAddress: varchar("ip_address", { length: 80 }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
