import { db } from "@/db";import { ensureDatabase } from "@/db/seed";import { sql } from "drizzle-orm";
export const dynamic="force-dynamic";export async function GET(){try{await db.execute(sql`select 1`);await ensureDatabase();return Response.json({ok:true,service:"kpop-atlas"})}catch(error){console.error(error);return Response.json({ok:false},{status:500})}}
