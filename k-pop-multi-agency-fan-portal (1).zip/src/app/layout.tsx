import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { TawkWidget } from "@/components/tawk-widget";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL("https://kpopatlas.com"),
  title: { default: "K-POP ATLAS — Your World of K-Pop", template: "%s | K-POP ATLAS" },
  description: "Explore verified K-Pop companies, artists, fan memberships, events, merchandise and global fan services.",
  keywords: ["K-Pop", "Korean music", "K-Pop artists", "fan membership", "K-Pop agencies"],
  openGraph: { title: "K-POP ATLAS", description: "Your trusted bridge to the global K-Pop universe.", type: "website" },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return <html lang="en"><body><Header/>{children}<Footer/><TawkWidget/></body></html>;
}
